/*
 * MSPI_Config.h
 *
 *  Created on: Oct 2, 2023
 *      Author: Shereef Mahmoud
 */

#ifndef MSPI_CONFIG_H_
#define MSPI_CONFIG_H_





#endif /* MSPI_CONFIG_H_ */
