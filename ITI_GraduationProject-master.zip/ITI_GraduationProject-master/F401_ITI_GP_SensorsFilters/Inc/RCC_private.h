#ifndef RCC_PRIVATE_H_
#define RCC_PRIVATE_H_

#define TIMEOUT			100000U

#endif




